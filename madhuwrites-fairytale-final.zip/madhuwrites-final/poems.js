/*
  ✦ madhuwrites — your poetry shelf

  HOW TO ADD A POEM:
  1. Copy one of the objects below.
  2. Change the title, category, excerpt and poem.
  3. Keep the quotation marks around text.
  4. Use \n for a new line inside the poem.

  You only need to edit THIS file when you want to add or change poems.
*/

const poems = [
  {
    title: "The Other Half",
    category: "longing",
    symbol: "☾",
    tone: "blue",
    excerpt: "A quiet place for a poem about moons, missing pieces and distance.",
    poem: "Your poem goes here.\n\nReplace this text with your own words."
  },
  {
    title: "Untitled, For Now",
    category: "love",
    symbol: "✿",
    tone: "lilac",
    excerpt: "A little room waiting for words that have not found their title yet.",
    poem: "Your poem goes here.\n\nAdd your own lines here."
  },
  {
    title: "How Much Warmth",
    category: "hope",
    symbol: "♡",
    tone: "pink",
    excerpt: "For the moments when kindness feels like sunlight returning to a quiet room.",
    poem: "Your poem goes here.\n\nAdd your own lines here."
  },
  {
    title: "Under the Same Sky",
    category: "distance",
    symbol: "☁",
    tone: "cream",
    excerpt: "Because sometimes distance is measured in skies, not miles.",
    poem: "Your poem goes here.\n\nAdd your own lines here."
  }
];
